﻿using HospitalMgmtSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalMgmtSystem.Store
{
    public static class UserStore
    {
        public static User User { get; set; }
    }
}
